// Configura tu backend
const API_BASE = window.API_BASE || "https://TU-BACKEND.up.railway.app";
const token = () => localStorage.getItem('token') || '';
const authHeaders = () => token() ? { 'Authorization': 'Bearer ' + token() } : {};
async function api(path, options={}){
  const res = await fetch(API_BASE + path, { headers: { 'Content-Type':'application/json', ...authHeaders(), ...(options.headers||{}) }, ...options });
  if(!res.ok){ let t='Error '+res.status; try{ const j=await res.json(); t=j.error || JSON.stringify(j) }catch{}; throw new Error(t); }
  return res.json();
}

// Quick validator (home)
const qForm = document.getElementById('quick-validate');
if(qForm){
  qForm.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const code=document.getElementById('q_code').value.trim(), hwid=document.getElementById('q_hwid').value.trim();
    const out=document.getElementById('q_result'); out.textContent='Validando...';
    try{ const r=await api('/api/keys/validate',{method:'POST',body:JSON.stringify({code,hwid})}); out.textContent=JSON.stringify(r,null,2); }
    catch(err){ out.textContent=err.message; }
  });
}

// Register
const regForm = document.getElementById('register-form');
if(regForm){
  regForm.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const body={ username:username.value.trim(), email:email.value.trim(), whatsapp:whatsapp.value.trim(), country:country.value.trim(), password:password.value };
    try{ const r=await api('/api/auth/register',{method:'POST',body:JSON.stringify(body)}); localStorage.setItem('token', r.token); location.href='/dashboard.html'; }
    catch(err){ alert(err.message); }
  });
}

// Login + 2FA
const loginForm = document.getElementById('login-form');
if(loginForm){
  loginForm.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const body={ email:document.getElementById('email').value.trim(), password:document.getElementById('password').value, otp:(document.getElementById('otp')&&document.getElementById('otp').value)||undefined };
    try{ const r=await api('/api/auth/login',{method:'POST',body:JSON.stringify(body)}); localStorage.setItem('token', r.token); location.href='/dashboard.html'; }
    catch(err){ alert(err.message); }
  });
}

// Dashboard
const logoutBtn = document.getElementById('logout'); if(logoutBtn){ logoutBtn.onclick=()=>{ localStorage.removeItem('token'); location.href='/login.html'; }; }
const genForm = document.getElementById('gen-form');
if(genForm){
  const list = async ()=>{
    const q = document.getElementById('search').value.trim();
    const data = await api('/api/keys' + (q?('?q='+encodeURIComponent(q)):'') );
    const cont = document.getElementById('keys-list'); cont.innerHTML='';
    data.forEach(k=>{
      const el=document.createElement('div'); el.className='border border-neutral-800 rounded-lg p-3 flex items-center justify-between';
      el.innerHTML = `<div><div class="font-mono text-sm">${k.code}</div><div class="text-neutral-400 text-xs">Plan ${k.plan} · Días ${k.days} · Producto: ${k.product_id||'—'} · Expira: ${k.expires_at||'—'} · HWID: ${k.hwid||'—'}</div></div><div class="flex gap-2"><button data-code="${k.code}" class="btn-revoke px-3 py-1 border border-neutral-700 rounded">Revocar</button></div>`;
      cont.appendChild(el);
    });
    cont.querySelectorAll('.btn-revoke').forEach(btn=> btn.onclick = async ()=>{ if(confirm('¿Revocar esta key?')){ await api('/api/keys/revoke',{method:'POST',body:JSON.stringify({code:btn.dataset.code})}); await list(); } });
  };
  document.getElementById('refresh').onclick=list; document.getElementById('search').oninput=(e)=>{ if(e.target.value.length===0) list(); };
  list();

  genForm.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const body={ prefix:prefix.value.trim()||'KEY', quantity:parseInt(quantity.value||'1',10), days:parseInt(days.value||'30',10), plan:plan.value,
      groups:parseInt(groups.value||'4',10), groupLen:parseInt(groupLen.value||'5',10), note:note.value.trim()||undefined,
      product_id:document.getElementById('product_id').value.trim()||undefined, device_limit:parseInt(document.getElementById('device_limit').value||'1',10),
      max_validations: parseInt(document.getElementById('max_validations').value||'0',10) || undefined };
    if(body.plan==='permanent') body.days=0;
    try{ const r=await api('/api/keys/generate',{method:'POST',body:JSON.stringify(body)}); document.getElementById('gen-result').value=r.keys.join('\n'); await list(); }
    catch(err){ alert(err.message); }
  });
}

// Role badge + admin link
(async ()=>{
  const b=document.getElementById('roleBadge'); if(!b) return;
  try{ await api('/api/users'); b.textContent='Admin/Owner'; } catch{ b.textContent='Usuario'; }
})();

// Admin page
const createUserForm = document.getElementById('create-user');
if(createUserForm){
  createUserForm.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const body={ username:document.getElementById('cu_username').value.trim(), email:document.getElementById('cu_email').value.trim(), password:document.getElementById('cu_password').value, role:document.getElementById('cu_role').value, daily_key_quota: parseInt(document.getElementById('cu_quota').value||'200',10)};
    try{ const r=await api('/api/users',{method:'POST',body:JSON.stringify(body)}); document.getElementById('create-user-result').textContent=JSON.stringify(r,null,2); await loadUsers(); }catch(err){ alert(err.message); }
  });
  async function loadUsers(){
    try{
      const users=await api('/api/users'); const cont=document.getElementById('users-list'); cont.innerHTML='';
      users.forEach(u=>{ const el=document.createElement('div'); el.className='border border-neutral-800 rounded-lg p-3 flex items-center justify-between';
        el.innerHTML=`<div><div class="font-semibold">${u.username} <span class="text-xs text-neutral-400">(${u.role})</span></div><div class="text-neutral-400">${u.email}</div><div class="text-neutral-500 text-xs">Cuota diaria: ${u.daily_key_quota}</div></div><div class="flex gap-2"><button data-id="${u.id}" class="btn-setq px-3 py-1 border border-neutral-700 rounded">Cuota</button><button data-id="${u.id}" class="btn-pass px-3 py-1 border border-neutral-700 rounded">Reset pass</button></div>`; cont.appendChild(el); });
      cont.querySelectorAll('.btn-setq').forEach(btn=> btn.onclick=async()=>{ const v=prompt('Nueva cuota diaria (keys/día):','200'); if(v){ await api('/api/users/'+btn.dataset.id,{method:'PATCH',body:JSON.stringify({daily_key_quota:parseInt(v,10)})}); await loadUsers(); } });
      cont.querySelectorAll('.btn-pass').forEach(btn=> btn.onclick=async()=>{ const v=prompt('Nueva contraseña:'); if(v){ await api('/api/users/'+btn.dataset.id,{method:'PATCH',body:JSON.stringify({password:v})}); alert('Contraseña actualizada'); } });
    }catch{ document.getElementById('users-list').textContent='No autorizado'; }
  } loadUsers();
}

// Products on home
async function renderProducts(){ const grid=document.getElementById('products'); if(!grid) return; try{ const prods=await api('/api/products'); grid.innerHTML=''; prods.forEach(p=>{ const el=document.createElement('div'); el.className='bg-neutral-900/60 border border-neutral-800 p-6 rounded-xl'; el.innerHTML=`<h4 class="font-bold text-lg mb-2">${p.name}</h4><p class="text-neutral-300 mb-3">${p.description||''}</p><a href="/checkout.html?product_id=${p.id}" class="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 inline-block">Comprar</a>`; grid.appendChild(el); }); }catch{ grid.textContent='No hay productos disponibles.'; } } renderProducts();

// Analytics page
async function loadAnalytics(){ const cards=document.getElementById('cards'); if(!cards) return; try{ const o=await api('/api/stats/overview'); cards.innerHTML=`<div class="bg-neutral-900/60 border border-neutral-800 p-6 rounded-xl"><div class="text-sm text-neutral-400">Keys totales</div><div class="text-3xl font-extrabold">${o.keys.total}</div></div><div class="bg-neutral-900/60 border border-neutral-800 p-6 rounded-xl"><div class="text-sm text-neutral-400">Keys activas</div><div class="text-3xl font-extrabold">${o.keys.activas}</div></div><div class="bg-neutral-900/60 border border-neutral-800 p-6 rounded-xl"><div class="text-sm text-neutral-400">Validaciones</div><div class="text-3xl font-extrabold">${o.validaciones}</div></div>`; const act=await api('/api/stats/activity?days=30'); const genCtx=document.getElementById('genChart')?.getContext('2d'); if(window.Chart&&genCtx){ new Chart(genCtx,{type:'line',data:{labels:act.generated.map(x=>new Date(x.d).toLocaleDateString()),datasets:[{label:'Keys generadas',data:act.generated.map(x=>x.c)}]}}); } const valCtx=document.getElementById('valChart')?.getContext('2d'); if(window.Chart&&valCtx){ new Chart(valCtx,{type:'line',data:{labels:act.validated.map(x=>new Date(x.d).toLocaleDateString()),datasets:[{label:'Validaciones',data:act.validated.map(x=>x.c)}]}}); } }catch(e){ cards.textContent='No autorizado'; } } loadAnalytics();

// Checkout demo
async function loadCheckout(){ const form=document.getElementById('checkout-form'); if(!form) return; const url=new URL(location.href); const pid=url.searchParams.get('product_id'); const select=document.getElementById('product'); try{ const prods=await api('/api/products'); prods.forEach(p=>{ const opt=document.createElement('option'); opt.value=p.id; opt.textContent=p.name; if(pid===p.id) opt.selected=true; select.appendChild(opt); }); }catch{} form.addEventListener('submit',(e)=>{ e.preventDefault(); const product_id=document.getElementById('product').value; const planDays=document.getElementById('plan').value; const email=document.getElementById('email').value; alert('Demo: redirige a Stripe/PayPal con metadata {product_id, plan_days, email}. Webhook crea la key.'); }); } loadCheckout();

// Enhanced validar page
(function(){ const form=document.getElementById('validate-form'); if(!form) return; const box=document.getElementById('resultBox'); const extras=document.getElementById('extras'); const gmsg=document.getElementById('globalMsg'); const vpre=document.getElementById('vars'); form.addEventListener('submit', async (e)=>{ e.preventDefault(); box.className='mt-4 rounded-lg p-4 bg-neutral-900 border border-neutral-800 text-neutral-300'; box.textContent='Validando...'; box.classList.remove('hidden'); extras.classList.add('hidden'); const code=document.getElementById('code').value.trim(); const hwid=document.getElementById('hwid').value.trim(); const product_id=document.getElementById('product_id').value.trim(); const client_note=document.getElementById('client_note').value.trim(); try{ const r=await api('/api/keys/validate',{method:'POST',body:JSON.stringify({code,hwid,client_note})}); if(r.valid){ box.className='mt-4 rounded-lg p-4 bg-emerald-900/40 border border-emerald-700 text-emerald-200'; box.textContent=`✅ Key válida. Plan: ${r.plan}. Expira: ${r.expires_at || '—'}`; }else{ box.className='mt-4 rounded-lg p-4 bg-rose-900/40 border border-rose-700 text-rose-200'; box.textContent='❌ Key inválida'; } if(product_id){ try{ const auth=await api('/api/client/authorize',{method:'POST',body:JSON.stringify({key:code,hwid,product_id})}); if(auth.ok){ extras.classList.remove('hidden'); const m=await api('/api/client/message?product_id='+encodeURIComponent(product_id)); gmsg.textContent=(m&&m.content)?m.content:'—'; const vars=await api('/api/client/variable?product_id='+encodeURIComponent(product_id)+'&name=version').catch(()=>null); vpre.textContent=vars?JSON.stringify(vars,null,2):'—'; } }catch{} } }catch(err){ box.className='mt-4 rounded-lg p-4 bg-rose-900/40 border border-rose-700 text-rose-200'; box.textContent='❌ '+err.message; } }); })();
