# KeyGen Store PRO (v4) — inspirado en KeyAuth

Frontend: **Netlify** · Backend: **Railway** (Node.js + Express + PostgreSQL)

## Funciones
- Multi-producto, HWID, límite de dispositivos, límite de validaciones
- Roles: owner/admin/reseller/user + cuotas diarias por socio
- API cliente (`/api/client/authorize`, `/api/client/variable`, `/api/client/message`)
- Variables en la nube y mensaje global por producto
- 2FA (TOTP) para login, notificaciones Discord/Telegram, Captcha opcional
- Webhooks de pago (Stripe/PayPal) que generan keys (stubs listos)
- Panel, Admin, Analítica y Checkout demo

## Despliegue
1) **Railway**: deploy carpeta `server/` y setea variables de entorno (ver `.env.example`).
2) **Netlify**: deploy carpeta `web/` y en `web/assets/js/app.js` cambia `API_BASE`.
3) Entra con `ADMIN_EMAIL`/`ADMIN_PASSWORD` (crea **owner**).

> Solo para software legítimo. No uses esto para infringir leyes o TOS de terceros.
